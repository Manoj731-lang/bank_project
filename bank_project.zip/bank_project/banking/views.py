from django.shortcuts import render, redirect, get_object_or_404
from django.db import transaction
from decimal import Decimal
from .models import Account, Transaction as BankTransaction

def create_account(request):
    if request.method == 'POST':
        account_number = request.POST['account_number']
        name = request.POST['name']
        balance = Decimal(request.POST['balance'])

        Account.objects.create(
            account_number=account_number,
            name=name,
            balance=balance
        )
        return redirect('account_detail', account_number=account_number)

    return render(request, 'create_account.html')


def account_detail(request, account_number):
    account = get_object_or_404(Account, account_number=account_number)
    return render(request, 'account_detail.html', {'account': account})


def deposit(request):
    if request.method == 'POST':
        account_number = request.POST['account_number']
        amount = Decimal(request.POST['amount'])

        account = get_object_or_404(Account, account_number=account_number)

        with transaction.atomic():
            account.balance += amount
            account.save()

            BankTransaction.objects.create(
                account=account,
                amount=amount,
                transaction_type=BankTransaction.DEPOSIT
            )

        return redirect('account_detail', account_number=account_number)

    return render(request, 'deposit.html')


def withdraw(request):
    if request.method == 'POST':
        account_number = request.POST['account_number']
        amount = Decimal(request.POST['amount'])

        account = get_object_or_404(Account, account_number=account_number)

        if account.balance < amount:
            return render(request, 'withdraw.html', {'error': 'Insufficient balance'})

        with transaction.atomic():
            account.balance -= amount
            account.save()

            BankTransaction.objects.create(
                account=account,
                amount=amount,
                transaction_type=BankTransaction.WITHDRAW
            )

        return redirect('account_detail', account_number=account_number)

    return render(request, 'withdraw.html')


def transactions(request, account_number):
    account = get_object_or_404(Account, account_number=account_number)
    txns = BankTransaction.objects.filter(account=account).order_by('-timestamp')
    return render(request, 'transactions.html', {'transactions': txns})
