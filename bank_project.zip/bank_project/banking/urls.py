from django.urls import path
from . import views

urlpatterns = [
    path('create/', views.create_account, name='create_account'),
    path('account/<str:account_number>/', views.account_detail, name='account_detail'),
    path('deposit/', views.deposit, name='deposit'),
    path('withdraw/', views.withdraw, name='withdraw'),
    path('transactions/<str:account_number>/', views.transactions, name='transactions'),
]
